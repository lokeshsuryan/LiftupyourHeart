package com.braintreepayments.api.test;

public class TestTokenizationKey {

    public static final String TOKENIZATION_KEY = "development_testing_integration_merchant_id";
}
