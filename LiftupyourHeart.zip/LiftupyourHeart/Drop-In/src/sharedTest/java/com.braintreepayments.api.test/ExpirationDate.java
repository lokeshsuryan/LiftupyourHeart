package com.braintreepayments.api.test;

public class ExpirationDate {

    public static final String VALID_EXPIRATION = "1219";
}
