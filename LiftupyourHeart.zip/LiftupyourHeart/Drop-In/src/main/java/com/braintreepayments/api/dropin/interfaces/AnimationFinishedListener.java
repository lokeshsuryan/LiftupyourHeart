package com.braintreepayments.api.dropin.interfaces;

public interface AnimationFinishedListener {
    void onAnimationFinished();
}
