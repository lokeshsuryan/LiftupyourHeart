package com.braintreepayments.api.dropin.interfaces;

import android.view.View;

public interface AddPaymentUpdateListener {
    void onPaymentUpdated(View v);
    void onBackRequested(View v);
}
