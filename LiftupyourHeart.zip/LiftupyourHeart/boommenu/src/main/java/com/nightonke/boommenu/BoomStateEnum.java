package com.nightonke.boommenu;

/**
 * Created by Weiping Huang at 01:09 on 16/11/29
 * For Personal Open Source
 * Contact me at 2584541288@qq.com or nightonke@outlook.com
 * For more projects: https://github.com/Nightonke
 */

enum BoomStateEnum {
    DidBoom,
    WillBoom,
    DidReboom,
    WillReboom
}
