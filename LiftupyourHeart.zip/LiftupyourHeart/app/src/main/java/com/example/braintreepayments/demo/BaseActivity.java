package com.example.braintreepayments.demo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.text.TextUtils;

import com.braintreepayments.api.BraintreeFragment;
import com.braintreepayments.api.interfaces.BraintreeCancelListener;
import com.braintreepayments.api.interfaces.BraintreeErrorListener;
import com.braintreepayments.api.interfaces.PaymentMethodNonceCreatedListener;
import com.braintreepayments.api.models.PaymentMethodNonce;
import com.example.braintreepayments.api.internal.SignatureVerificationOverrides;
import com.example.braintreepayments.demo.models.ClientToken;
import com.example.rest.ServiceGenerator;
import com.example.rest.Singleton;
import com.paypal.android.sdk.onetouch.core.PayPalOneTouchCore;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

@SuppressWarnings("deprecation")
public abstract class BaseActivity extends Fragment implements ActivityCompat.OnRequestPermissionsResultCallback,
        PaymentMethodNonceCreatedListener, BraintreeCancelListener, BraintreeErrorListener,
        ActionBar.OnNavigationListener {

    private static final String KEY_AUTHORIZATION = "com.braintreepayments.demo.KEY_AUTHORIZATION";

    protected String mAuthorization;
    protected String mCustomerId;
    protected BraintreeFragment mBraintreeFragment;
    protected Logger mLogger;

    private boolean mActionBarSetup;

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mLogger = LoggerFactory.getLogger(getClass().getSimpleName());

        if (savedInstanceState != null && savedInstanceState.containsKey(KEY_AUTHORIZATION)) {
            mAuthorization = savedInstanceState.getString(KEY_AUTHORIZATION);
        }
        ServiceGenerator.changeApiBaseUrl(Settings.getSandboxUrl());
    }


    @Override
    public void onResume() {
        super.onResume();

       /* if (!mActionBarSetup) {
            setupActionBar();
            mActionBarSetup = true;
        }*/

        SignatureVerificationOverrides.disableAppSwitchSignatureVerification(
                Settings.isPayPalSignatureVerificationDisabled(getActivity()));
        PayPalOneTouchCore.useHardcodedConfig(getActivity(), Settings.useHardcodedPayPalConfiguration(getActivity()));
        handleAuthorizationState();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        handleAuthorizationState();
    }

    private void handleAuthorizationState() {
        if (mAuthorization == null ||
                (Settings.useTokenizationKey(getActivity()) && !mAuthorization.equals(Settings.getEnvironmentTokenizationKey(getActivity()))) ||
                !TextUtils.equals(mCustomerId, Settings.getCustomerId(getActivity()))) {
            performReset();
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mAuthorization != null) {
            outState.putString(KEY_AUTHORIZATION, mAuthorization);
        }
    }

    @Override
    public void onPaymentMethodNonceCreated(PaymentMethodNonce paymentMethodNonce) {
        mLogger.debug("Payment Method Nonce received: " + paymentMethodNonce.getTypeLabel());
    }

    @Override
    public void onCancel(int requestCode) {
        mLogger.debug("Cancel received: " + requestCode);
    }

    @Override
    public void onError(Exception error) {
        mLogger.debug("Error received (" + error.getClass() + "): "  + error.getMessage());
        mLogger.debug(error.toString());

        showDialog("An error occurred (" + error.getClass() + "): " + error.getMessage());
    }

    private void performReset() {
        try {
            mAuthorization = null;
            mCustomerId = Settings.getCustomerId(getActivity());

            if (mBraintreeFragment == null) {
                mBraintreeFragment = (BraintreeFragment) getActivity().getFragmentManager()
                        .findFragmentByTag(BraintreeFragment.TAG);
            }

            if (mBraintreeFragment != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    getActivity().getFragmentManager().beginTransaction().remove(mBraintreeFragment).commitNow();
                } else {
                    getActivity().getFragmentManager().beginTransaction().remove(mBraintreeFragment).commit();
                    getFragmentManager().executePendingTransactions();
                }

                mBraintreeFragment = null;
            }

            reset();
            fetchAuthorization();
        }
        catch(Exception e){

        }
    }

    protected abstract void reset();

    protected abstract void onAuthorizationFetched();

    protected void fetchAuthorization() {
        if (mAuthorization != null) {
            onAuthorizationFetched();
        } else if (Settings.useTokenizationKey(getActivity())) {
            mAuthorization = Settings.getEnvironmentTokenizationKey(getActivity());
            onAuthorizationFetched();
        } else {

            Call<ClientToken> call = Singleton.getInstance().getRestOkClient().getClientToken(Settings.getCustomerId(getActivity()), Settings.getMerchantAccountId(getActivity()));
            call.enqueue(ClientToken);


        }
    }

    protected void showDialog(String message) {
        new AlertDialog.Builder(getActivity())
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .show();
    }
    @Override
    public boolean onNavigationItemSelected(int itemPosition, long itemId) {
        if (Settings.getEnvironment(getActivity()) != itemPosition) {
            Settings.setEnvironment(getActivity(), itemPosition);
            performReset();
        }
        return true;
    }

   /* @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return false;
        }
    }
    */

    private Callback<ClientToken> ClientToken = new Callback<ClientToken>() {
        @Override
        public void onResponse(Call<ClientToken> call, Response<ClientToken> response) {


            if (TextUtils.isEmpty(response.body().getClientToken())) {
                showDialog("Client token was empty");
            } else {
                mAuthorization = response.body().getClientToken();
                onAuthorizationFetched();
            }

        }

        @Override
        public void onFailure(Call<ClientToken> call, Throwable t) {
            //mActivity.hideProgressDialog();

            showDialog("Unable to get a client token. Response Code: " +
                    t.getStackTrace().toString() + " Response body: ");
        }
    };
}
