package com.example.fragment;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.adapter.AnsweredListRecyclerViewAdapter;
import com.example.liftupyourheart.BuilderManager;
import com.example.liftupyourheart.R;
import com.example.liftupyourheart.databinding.FragmentAnsweredListItemBinding;
import com.example.model.AnswerListDao;
import com.example.model.PrayerDao;
import com.example.model.ServerResponseHeart;
import com.example.viewModel.SignUpViewModel;
import com.nightonke.boommenu.BoomButtons.BoomButton;
import com.nightonke.boommenu.OnBoomListener;

import java.util.ArrayList;
import java.util.List;

/**
 * A fragment representing a list of Items.
 * <p/>
 * Activities containing this fragment MUST implement the {}
 * interface.
 */
public class AnsweredListFragment  extends Fragment implements View.OnClickListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    FragmentAnsweredListItemBinding binding;
    AnsweredListRecyclerViewAdapter answeredListRecyclerViewAdapter;
    private static AnsweredListFragment instance = null;
    int mColumnCount = 1;
    ArrayList<PrayerDao> prayerDaoList;
    SignUpViewModel signUpViewModel;
    public static AnsweredListFragment getInstance() {
        if (instance == null) {
            instance = new AnsweredListFragment();
        }
        return instance;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_answered_list_item, null, false);
        View view = binding.getRoot();
        initView();
        return view;
    }

    private void initView() {
       setActionBar();
        binding.homeIB.setOnClickListener(this);
        binding.upDownIB.setOnClickListener(this);
        signUpViewModel = ViewModelProviders.of(this).get(SignUpViewModel.class);
        if (mColumnCount <= 1) {
            binding.allReminder.setLayoutManager(new LinearLayoutManager(getActivity()));
        } else {
            binding.allReminder.setLayoutManager(new GridLayoutManager(getActivity(), mColumnCount));
        }
        //prayerDaoList=new ArrayList<>();

        assert binding.bmb != null;
        for (int i = 0; i < binding.bmb.getPiecePlaceEnum().pieceNumber(); i++)
            binding.bmb.addBuilder(BuilderManager.getTextOutsideCircleButtonBuilderWithDifferentPieceColor());

        binding.bmb.setOnBoomListener(new OnBoomListener() {
            @Override
            public void onClicked(int index, BoomButton boomButton) {
                // If you have implement listeners for boom-buttons in builders,
                // then you shouldn't add any listener here for duplicate callbacks.
                Log.d("BMB", "onBoomWillHide: " + index);
                if (index == 0) {
                    loadFragment(PrayerFragment.getInstance(), "PrayerFragment");

                } else if (index == 1) {

                } else if (index == 2) {

                } else if (index == 3) {
                    loadFragment(SettingFragment.getInstance(), "SettingFragment");
                } else if (index == 4) {
                    loadFragment(ViewGroupFragment.getInstance(), "ViewGroupFragment");
                } else if (index == 5) {
                    loadFragment(CreateGroupFragment.getInstance(), "CreateGroupFragment");

                }
            }

            @Override
            public void onBackgroundClick() {
                // textViewForAnimation.setText("Click background!!!");
            }

            @Override
            public void onBoomWillHide() {
                Log.d("BMB", "onBoomWillHide: ");
            }

            @Override
            public void onBoomDidHide() {
                Log.d("BMB", "onBoomDidHide: ");

            }

            @Override
            public void onBoomWillShow() {
                Log.d("BMB", "onBoomWillShow: ");
            }

            @Override
            public void onBoomDidShow() {
                Log.d("BMB", "onBoomDidShow: ");
            }
        });

    }
    private void setActionBar() {
        binding.toolbar.setBackgroundColor(getResources().getColor(R.color.actionBarColor));
        binding.toolbar.setTitle("");
        AppCompatActivity activity = (AppCompatActivity) getActivity();
        activity.setSupportActionBar(binding.toolbar);
        activity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        activity.getSupportActionBar().setHomeAsUpIndicator(R.drawable.back_icon);
        this.setHasOptionsMenu(true);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.homeIB:
                getActivity().getSupportFragmentManager().popBackStack();
                break;
            case R.id.upDownIB:
                break;
            case R.id.newGroup:
                loadFragment(AddPrayerFragment.getInstance(),"AddPrayerFragment");
                break;
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        showProgressbar();
        signUpViewModel.answerPrayerList().observe(this, new Observer<ServerResponseHeart<List<AnswerListDao>>>() {
            @Override
            public void onChanged(@Nullable ServerResponseHeart<List<AnswerListDao>> serverResponse) {
                if (serverResponse != null) {
                    if (serverResponse.getResponse() == 1) {
                        List<AnswerListDao> answerList=serverResponse.getData();
                        answeredListRecyclerViewAdapter = new AnsweredListRecyclerViewAdapter(answerList,getActivity());
                        binding.allReminder.setAdapter(answeredListRecyclerViewAdapter);
                    } else {
                        Toast.makeText(getActivity(), serverResponse.getMessage(), Toast.LENGTH_LONG).show();

                    }
                }
                hideProgressbar();
            }
        });
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
    }

    private void loadFragment(Fragment fragment , String type) {
// create a FragmentManager
        FragmentManager fm = getActivity().getSupportFragmentManager();
// create a FragmentTransaction to begin the transaction and replace the Fragment
        FragmentTransaction fragmentTransaction = fm.beginTransaction();
// replace the FrameLayout with new Fragment
        fragmentTransaction.replace(R.id.fragments, fragment);
        fragmentTransaction.addToBackStack(type);
        fragmentTransaction.commit(); // save the changes
    }

    public void hideProgressbar() {
        binding.loaderLayoutPrayer.setVisibility(View.GONE);
    }

    public void showProgressbar() {
        binding.loaderLayoutPrayer.setVisibility(View.VISIBLE);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                getFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                break;
        }
        return true;
    }
}