package com.example.braintreepayments.demo;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;

import com.braintreepayments.api.models.CardNonce;
import com.braintreepayments.api.models.PaymentMethodNonce;
import com.example.braintreepayments.demo.models.Transaction;
import com.example.liftupyourheart.R;
import com.example.liftupyourheart.databinding.CreateTransactionActivityBinding;
import com.example.rest.Singleton;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CreateTransactionActivity extends AppCompatActivity {

    public static final String EXTRA_PAYMENT_METHOD_NONCE = "nonce";
    public CreateTransactionActivityBinding bind;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bind= DataBindingUtil.setContentView(this, R.layout.create_transaction_activity);
        setTitle(R.string.processing_transaction);

        sendNonceToServer((PaymentMethodNonce) getIntent().getParcelableExtra(EXTRA_PAYMENT_METHOD_NONCE));
    }
    private Callback<Transaction> ClientToken = new Callback<Transaction>() {
        @Override
        public void onResponse(Call<Transaction> call, Response<Transaction> response) {
            Transaction transaction=response.body();
            if (transaction.getMessage() != null &&
                    transaction.getMessage().startsWith("created")) {
                setStatus(R.string.transaction_complete);
                setMessage(transaction.getMessage());
            } else {
                setStatus(R.string.transaction_failed);
                if (TextUtils.isEmpty(transaction.getMessage())) {
                    setMessage("Server response was empty or malformed");
                } else {
                    setMessage(transaction.getMessage());
                }
            }
        }

        @Override
        public void onFailure(Call<Transaction> call, Throwable t) {
            //mActivity.hideProgressDialog();
            setStatus(R.string.transaction_failed);
            setMessage("Unable to create a transaction. Response Code: " +
                    "" + " Response body: " +
                    "");
        }
    };
    private void sendNonceToServer(PaymentMethodNonce nonce) {

        if (Settings.isThreeDSecureEnabled(this) && Settings.isThreeDSecureRequired(this)) {
            Call<Transaction> call = Singleton.getInstance().getRestOkClient().createTransaction(nonce.getNonce(),
                    Settings.getThreeDSecureMerchantAccountId(this),true);
            call.enqueue(ClientToken);

        } else if (Settings.isThreeDSecureEnabled(this)) {
            Call<Transaction> call = Singleton.getInstance().getRestOkClient().createTransaction(nonce.getNonce(),
                    Settings.getThreeDSecureMerchantAccountId(this));
            call.enqueue(ClientToken);

        } else if (nonce instanceof CardNonce && ((CardNonce) nonce).getCardType().equals("UnionPay")) {
            Call<Transaction> call = Singleton.getInstance().getRestOkClient().createTransaction(nonce.getNonce(),
                    Settings.getUnionPayMerchantAccountId(this));
            call.enqueue(ClientToken);

        } else {
            Call<Transaction> call = Singleton.getInstance().getRestOkClient().createTransaction(nonce.getNonce(),
                    Settings.getMerchantAccountId(this));
            call.enqueue(ClientToken);

        }
    }

    private void setStatus(int message) {
        bind.loadingSpinner.setVisibility(View.GONE);
        setTitle(message);
        bind.transactionStatus.setText(message);
        bind.transactionStatus.setVisibility(View.VISIBLE);
    }

    private void setMessage(String message) {
        bind.loadingSpinner.setVisibility(View.GONE);
        bind.transactionStatus.setText(message);
        bind.transactionStatus.setVisibility(View.VISIBLE);
    }
}
