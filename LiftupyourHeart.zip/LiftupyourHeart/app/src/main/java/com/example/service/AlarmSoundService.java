package com.example.service;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.widget.Toast;

import com.example.liftupyourheart.R;
import com.example.utills.PreferanceUtils;

import static com.example.fragment.AddReminderFragment.ALARM_REQUEST_CODE;

/**
 * Created by sonu on 10/04/17.
 */

public class AlarmSoundService extends Service {
    private MediaPlayer mediaPlayer;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        int rowidFirst = PreferanceUtils.getSettingPrayerTime(this, "timerFinished");
        int rowidNext = PreferanceUtils.getSettingPrayerTime(this, "nextPrayerNoti");
        if (rowidFirst != 0) {
            mediaPlayer = MediaPlayer.create(this, rowidFirst);

        } else if (rowidNext != 0) {
            mediaPlayer = MediaPlayer.create(this, rowidNext);

        } else if (rowidNext == 0 && rowidFirst == 0) {
            mediaPlayer = MediaPlayer.create(this, R.raw.alarm1);

        }
        mediaPlayer.start();
        mediaPlayer.setLooping(true);//set looping true to run it infinitely
        int ringTime = PreferanceUtils.getSettingPrayerTime(this, "prayerRingTime");
        if (ringTime > 0) {
            Handler mHandler = new Handler();
            mHandler.postDelayed(new Runnable() {
                public void run() {
                    try {
                        mediaPlayer.setLooping(false);
                        mediaPlayer.stop();
                        stopAlarmManager();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }, ringTime);
        }
        else{
            Handler mHandler = new Handler();
            mHandler.postDelayed(new Runnable() {
                public void run() {
                    try {
                        mediaPlayer.setLooping(false);
                        mediaPlayer.stop();
                        stopAlarmManager();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }, 2*60*1000);
        }
    }

    public void stopAlarmManager() {
        Intent alarmIntent = new Intent(this, BroadcastReceiver.class);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, ALARM_REQUEST_CODE, alarmIntent, 0);

        AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        manager.cancel(pendingIntent);//cancel the alarm manager of the pending intent


        //Stop the Media Player Service to stop sound
        stopService(new Intent(this, AlarmSoundService.class));

        //remove the notification from notification tray
        NotificationManager notificationManager = (NotificationManager) this
                .getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancel(AlarmNotificationService.NOTIFICATION_ID);

        Toast.makeText(this, "Alarm Canceled/Stop by given time in setting.", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        //On destory stop and release the media player
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
            mediaPlayer.reset();
            mediaPlayer.release();
        }
    }
}
