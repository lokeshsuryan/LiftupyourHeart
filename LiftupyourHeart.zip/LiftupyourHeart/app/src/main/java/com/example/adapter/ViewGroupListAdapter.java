package com.example.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.custom.CustomTextViewBlack;
import com.example.liftupyourheart.R;
import com.example.model.GroupDetailDao;

import java.util.List;

public class ViewGroupListAdapter extends RecyclerView.Adapter<ViewGroupListAdapter.Holder> {
    private List<GroupDetailDao> lists;
    private Activity mContext;

    public ViewGroupListAdapter(Activity context, List<GroupDetailDao> lists) {
        try {
            this.lists = lists;
            mContext = context;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return lists.size();
    }

    @Override
    public ViewGroupListAdapter.Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_group_listitem, parent, false);
        return new ViewGroupListAdapter.Holder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewGroupListAdapter.Holder holder, int position) {
        GroupDetailDao groupDetailDao = lists.get(position);
        holder.bind(groupDetailDao);
    }





    class Holder extends RecyclerView.ViewHolder {
        private CustomTextViewBlack txtGroupName;
        private CustomTextViewBlack txtContactNumber;

        public Holder(View convertView) {

            super(convertView);

            txtGroupName = (CustomTextViewBlack) convertView.findViewById(R.id.txtGroupName);


            /**
             * move on phone call
             */




        }

        public void bind(GroupDetailDao groupDetailDao) {
            txtGroupName.setText(groupDetailDao.getName());
        }
    }


}