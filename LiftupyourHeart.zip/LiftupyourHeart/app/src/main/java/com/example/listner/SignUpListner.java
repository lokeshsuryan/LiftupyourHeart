package com.example.listner;

public interface SignUpListner {

    void signUpMethod();
    void loginMethod();
}
