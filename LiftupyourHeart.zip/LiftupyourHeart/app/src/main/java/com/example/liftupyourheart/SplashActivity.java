package com.example.liftupyourheart;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.service.HomeIntentService;
import com.example.utills.AppConstant;
import com.example.utills.PreferanceUtils;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
        setContentView(R.layout.signup_popup);
        LinearLayout buttonLL=(LinearLayout)findViewById(R.id.buttonLL);
        TextView textView=(TextView)findViewById(R.id.liftUpMyHeart);

        SpannableString spannableString = new SpannableString("LIFT UP MY HEART");
        spannableString.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.dark_blue)), 0, 10, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableString.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.red)), 11, spannableString.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(spannableString);
        buttonLL.setVisibility(View.INVISIBLE);
        new Handler().postDelayed(()-> {

                proceedToTheNextActivity();
        }, 1500);
    }

    private void proceedToTheNextActivity() {
        //PreferanceUtils.setLoginUserID(this,"27","7341112202");
      /*  Intent registerIntent = new Intent(this, MainActivity.class);
        startActivity(registerIntent);
        finish();*/
        if (PreferanceUtils.getLoginDetail(SplashActivity.this) != null && PreferanceUtils.getLoginDetail(SplashActivity.this)!=null) {
            AppConstant.userId=PreferanceUtils.getLoginDetail(this).getData().getId();
            Intent msgIntent = new Intent(this, HomeIntentService.class);
            startService(msgIntent);
            Intent registerIntent = new Intent(this, MainActivity.class);
            startActivity(registerIntent);
            finish();
        } else {
            Intent registerIntent = new Intent(this, SignUpGuideLineActivity.class);
            startActivity(registerIntent);
            finish();
        }
    }
}

