package com.example.viewModel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import com.example.model.GroupDetailDao;
import com.example.model.ServerResponseHeart;
import com.example.rest.ProjectRepository;

import java.util.List;

public class ViewGroupModel extends AndroidViewModel {

    public ViewGroupModel(@NonNull Application application) {
        super(application);
    }

    public LiveData<ServerResponseHeart<List<GroupDetailDao>>> getGroupList(String userId){
        return ProjectRepository.getInstance().getGroupRespone(userId);
    }
}
