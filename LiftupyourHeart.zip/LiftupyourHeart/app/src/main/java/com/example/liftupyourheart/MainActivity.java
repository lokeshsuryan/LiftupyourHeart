package com.example.liftupyourheart;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.example.fragment.HomeFragment;
import com.example.liftupyourheart.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding bind;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bind = DataBindingUtil.setContentView(this, R.layout.activity_main);

        initView();

    }

    private void initView() {
        bind.toolbar.setTitle("");
        setSupportActionBar(bind.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        loadFragment(new HomeFragment(), "homeFragment");
    }

    public void showActionBar(Boolean show, String title) {
        bind.toolbar.setTitle("");
        bind.toolbarTitle.setText(title);
        setSupportActionBar(bind.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(show);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.back_icon);

    }

    public void showActionBarTitle(Boolean show, int title, int color) {
        bind.toolbar.setTitle(title);
        bind.toolbar.setBackgroundColor(color);
        bind.toolbarTitle.setText("");
        setSupportActionBar(bind.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(show);
    }

    public void showActionBarTitleBgColor(Boolean show, int title, int color) {
        bind.toolbar.setTitle("");
        bind.toolbar.setBackgroundColor(color);
        bind.toolbarTitle.setText(title);
        setSupportActionBar(bind.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(show);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.back_icon);

    }

    private void loadFragment(Fragment fragment, String type) {
// create a FragmentManager
        bind.fragments.setVisibility(View.VISIBLE);
        FragmentManager fm = getSupportFragmentManager();
// create a FragmentTransaction to begin the transaction and replace the Fragment
        FragmentTransaction fragmentTransaction = fm.beginTransaction();
// replace the FrameLayout with new Fragment
        fragmentTransaction.replace(R.id.fragments, fragment);
        fragmentTransaction.addToBackStack(type);
        fragmentTransaction.commit(); // save the changes

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                getSupportFragmentManager().popBackStack();
                break;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() > 0) {
            getFragmentManager().popBackStackImmediate();
        }else {
            super.onBackPressed();
        }
    }
}
