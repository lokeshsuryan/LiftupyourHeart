package com.example.utills;

/**
 * Created by lokeshkumar on 13/03/18.
 */

public class AppConstant {
    public static String BASE_URL = "http://qrmp.co/app/";
    public static final int CONNECTION_TIMEOUT = 120000;
    public static final String PRIVACY_POLCY = "http://liftupmyheart.com/privacy.html";
    public static final String TERMS_CONDITION = "http://liftupmyheart.com/terms.html";
    public static  String userId = "";
    public static final String PREFERENCE_NAME = "com.example.liftuoyourHart";
    public static final String PREFERANCE_CONTACTS = PREFERENCE_NAME + "contacts";
    public static  int alearmId =0;
    public static  String prayerName ="";



}
