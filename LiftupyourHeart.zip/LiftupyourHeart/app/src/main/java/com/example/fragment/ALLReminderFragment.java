package com.example.fragment;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.example.adapter.ReminderListAdapter;
import com.example.liftupyourheart.BuilderManager;
import com.example.liftupyourheart.MainActivity;
import com.example.liftupyourheart.R;
import com.example.liftupyourheart.databinding.FragmentPrayerBinding;
import com.example.model.AlarmDao;
import com.example.utills.AppConstant;
import com.example.utills.PreferanceUtils;
import com.google.gson.Gson;
import com.nightonke.boommenu.BoomButtons.BoomButton;
import com.nightonke.boommenu.OnBoomListener;

import java.util.List;

public class ALLReminderFragment extends Fragment implements View.OnClickListener {

    // TODO: Customize parameter argument names
    private static final String ARG_COLUMN_COUNT = "column-count";
    // TODO: Customize parameters
    private int mColumnCount = 1;
    FragmentPrayerBinding binding;

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public ALLReminderFragment() {
    }

    // TODO: Customize parameter initialization
    @SuppressWarnings("unused")
    public static ALLReminderFragment getInstance() {
        ALLReminderFragment fragment = new ALLReminderFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_prayer, null, false);
        View view = binding.getRoot();
        initView();
        return view;
        // Set the adapter
    }

    private void initView() {
        setActionBar();
        binding.newReminderOrPrayer.setOnClickListener(this);
        binding.homeIB.setOnClickListener(this);
        binding.upDownIB.setVisibility(View.INVISIBLE);
        if (mColumnCount <= 1) {
            binding.allReminder.setLayoutManager(new LinearLayoutManager(getActivity()));
        } else {
            binding.allReminder.setLayoutManager(new GridLayoutManager(getActivity(), mColumnCount));
        }

        assert binding.bmb != null;
        for (int i = 0; i < binding.bmb.getPiecePlaceEnum().pieceNumber(); i++)
            binding.bmb.addBuilder(BuilderManager.getTextOutsideCircleButtonBuilderWithDifferentPieceColor());
        binding.bmb.setOnBoomListener(new OnBoomListener() {
            @Override
            public void onClicked(int index, BoomButton boomButton) {
                // If you have implement listeners for boom-buttons in builders,
                // then you shouldn't add any listener here for duplicate callbacks.
                //Log.d("BMB", "onBoomWillHide: " + index);
                if (index == 0) {
                    //loadFragment(PrayerFragment.getInstance(), "PrayerFragment");
                } else if (index == 1) {
                    loadFragment(ALLReminderFragment.getInstance(), "AnsweredListFragment");
                } else if (index == 2) {
                    loadFragment(AnsweredListFragment.getInstance(), "AnsweredListFragment");
                } else if (index == 3) {
                    loadFragment(SettingFragment.getInstance(), "SettingFragment");
                } else if (index == 4) {
                    loadFragment(ViewGroupFragment.getInstance(), "ViewGroupFragment");

                } else if (index == 5) {
                    loadFragment(CreateGroupFragment.getInstance(), "CreateGroupFragment");

                }
            }

            @Override
            public void onBackgroundClick() {
                // textViewForAnimation.setText("Click background!!!");
                Gson gson = new Gson();
                //PreferanceUtils.setFirstPrayer(getActivity(), gson.toJson(prayerDaoList));

            }


            @Override
            public void onBoomWillHide() {
                Log.d("BMB", "onBoomWillHide: ");
            }

            @Override
            public void onBoomDidHide() {
                Log.d("BMB", "onBoomDidHide: ");

            }

            @Override
            public void onBoomWillShow() {
                Log.d("BMB", "onBoomWillShow: ");
            }

            @Override
            public void onBoomDidShow() {
                Log.d("BMB", "onBoomDidShow: ");
            }
        });
    }

    private void setActionBar() {

        ((MainActivity) getActivity()).showActionBarTitleBgColor(true, R.string.you_prayer, R.color.actionBarColor);
    }

    private void loadFragment(Fragment fragment, String type) {
// create a FragmentManager
        FragmentManager fm = getActivity().getSupportFragmentManager();
// create a FragmentTransaction to begin the transaction and replace the Fragment
        FragmentTransaction fragmentTransaction = fm.beginTransaction();
// replace the FrameLayout with new Fragment
        fragmentTransaction.replace(R.id.fragments, fragment);
        fragmentTransaction.addToBackStack(type);
        fragmentTransaction.commit(); // save the changes
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.newReminderOrPrayer:
                AppConstant.alearmId = 0;
                AppConstant.prayerName = "";
                loadFragment(AddReminderFragment.getInstance(), "AddReminderFragment");
                break;
            case R.id.homeIB:
                getActivity().getSupportFragmentManager().popBackStack();
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        ((MainActivity) getActivity()).getSupportActionBar().show();
        List<AlarmDao> alarmDaoList = PreferanceUtils.getReminderList(getActivity());
        if (alarmDaoList != null)
            binding.allReminder.setAdapter(new ReminderListAdapter(getActivity(), alarmDaoList));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                getActivity().getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                return true;
        }
        return true;
    }
}
