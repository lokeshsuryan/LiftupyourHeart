package com.example.fragment;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.liftupyourheart.R;
import com.example.liftupyourheart.databinding.FragmentAnswerBinding;
import com.example.model.AnswerPrayerDao;
import com.example.model.ServerResponse;
import com.example.utills.AppConstant;
import com.example.viewModel.SignUpViewModel;


public class AnswerPrayerFragment extends Fragment implements View.OnClickListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER;
    String pid;
    FragmentAnswerBinding binding;
    SignUpViewModel signUpViewModel;

    public AnswerPrayerFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_answer, null, false);
        View view = binding.getRoot();
        initView();
        return view;
    }

    private void initView() {
        setActionBar();
        Bundle bundle = getArguments();
        String title = bundle.getString("title");
        String desc = bundle.getString("desc");
        pid = bundle.getString("pid");
        binding.title.setText(title);
        binding.description.setText(desc);
        binding.deletePrayer.setOnClickListener(this);
        binding.answerPrayer.setOnClickListener(this);
        signUpViewModel = ViewModelProviders.of(this).get(SignUpViewModel.class);


    }
    private void setActionBar() {
        binding.toolbar.setBackgroundColor(getResources().getColor(R.color.actionBarColor));
        binding.toolbar.setTitle("");
        AppCompatActivity activity = (AppCompatActivity) getActivity();
        activity.setSupportActionBar(binding.toolbar);
        activity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        activity.getSupportActionBar().setHomeAsUpIndicator(R.drawable.back_icon);
        this.setHasOptionsMenu(true);
    }
    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();

    }

    @Override
    public void onClick(View v) {
        AnswerPrayerDao answerPrayerDao;
        switch (v.getId()) {
            case R.id.answerPrayer:
                showProgressbar();
                 answerPrayerDao=new AnswerPrayerDao();
                answerPrayerDao.setAnswer("1");
                answerPrayerDao.setUser_id(AppConstant.userId);
                signUpViewModel.answerPrayer(pid,answerPrayerDao).observe(this, new Observer<ServerResponse>() {
                    @Override
                    public void onChanged(@Nullable ServerResponse serverResponse) {
                        if (serverResponse != null) {
                            if (serverResponse.getResponse() == 1) {
                                Toast.makeText(getActivity(), serverResponse.getMessage(), Toast.LENGTH_LONG).show();
                                getActivity().getSupportFragmentManager().popBackStack();
                            } else {
                                Toast.makeText(getActivity(), serverResponse.getMessage(), Toast.LENGTH_LONG).show();

                            }
                        }
                        hideProgressbar();
                    }
                });
                break;
            case R.id.deletePrayer:
                showProgressbar();
                 answerPrayerDao=new AnswerPrayerDao();
                 answerPrayerDao.setUser_id(AppConstant.userId);
                signUpViewModel.deletePrayer(pid,answerPrayerDao).observe(this, new Observer<ServerResponse>() {
                    @Override
                    public void onChanged(@Nullable ServerResponse serverResponse) {
                        if (serverResponse != null) {
                            if (serverResponse.getResponse() == 1) {
                                Toast.makeText(getActivity(), serverResponse.getMessage(), Toast.LENGTH_LONG).show();
                                getActivity().getSupportFragmentManager().popBackStack();
                            } else {
                                Toast.makeText(getActivity(), serverResponse.getMessage(), Toast.LENGTH_LONG).show();

                            }
                        }
                        hideProgressbar();
                    }
                });
                break;
        }

    }

    public void hideProgressbar() {
        binding.loaderLayoutAP.setVisibility(View.GONE);
    }

    public void showProgressbar() {
        binding.loaderLayoutAP.setVisibility(View.VISIBLE);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                getFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                break;
        }
        return true;
    }
}
