package com.example.fragment;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import com.braintreepayments.api.AndroidPay;
import com.braintreepayments.api.BraintreeFragment;
import com.braintreepayments.api.PayPal;
import com.braintreepayments.api.dropin.DropInActivity;
import com.braintreepayments.api.dropin.DropInRequest;
import com.braintreepayments.api.dropin.DropInResult;
import com.braintreepayments.api.dropin.utils.PaymentMethodType;
import com.braintreepayments.api.exceptions.InvalidArgumentException;
import com.braintreepayments.api.interfaces.BraintreeCancelListener;
import com.braintreepayments.api.interfaces.BraintreeErrorListener;
import com.braintreepayments.api.interfaces.PaymentMethodNonceCreatedListener;
import com.braintreepayments.api.models.AndroidPayCardNonce;
import com.braintreepayments.api.models.CardNonce;
import com.braintreepayments.api.models.ClientToken;
import com.braintreepayments.api.models.GooglePaymentCardNonce;
import com.braintreepayments.api.models.GooglePaymentRequest;
import com.braintreepayments.api.models.PayPalAccountNonce;
import com.braintreepayments.api.models.PaymentMethodNonce;
import com.braintreepayments.api.models.PostalAddress;
import com.braintreepayments.api.models.VenmoAccountNonce;
import com.example.adapter.GroupAdapter;
import com.example.braintreepayments.demo.BaseActivity;
import com.example.braintreepayments.demo.CreateTransactionActivity;
import com.example.braintreepayments.demo.Settings;
import com.example.liftupyourheart.MainActivity;
import com.example.liftupyourheart.R;
import com.example.liftupyourheart.databinding.CreateGroupFragmentBinding;
import com.example.model.ContactDao;
import com.example.model.CreateGroupDao;
import com.example.model.Data;
import com.example.model.GroupItemDao;
import com.example.utills.PreferanceUtils;
import com.example.utills.Utills;
import com.example.viewModel.AddGroupViewModel;
import com.google.android.gms.identity.intents.model.CountrySpecification;
import com.google.android.gms.identity.intents.model.UserAddress;
import com.google.android.gms.wallet.Cart;
import com.google.android.gms.wallet.LineItem;
import com.google.android.gms.wallet.TransactionInfo;
import com.google.android.gms.wallet.WalletConstants;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;


public class CreateGroupFragment extends BaseActivity implements View.OnClickListener, PaymentMethodNonceCreatedListener,
        BraintreeCancelListener, BraintreeErrorListener, DropInResult.DropInResultListener {

    private static final int DROP_IN_REQUEST = 100;

    private static final String KEY_NONCE = "nonce";

    private PaymentMethodType mPaymentMethodType;
    private PaymentMethodNonce mNonce;
    private ProgressDialog mLoading;
    String amount;
    String trnId;
    List<GroupItemDao> selectedMember;
    String groupName;
    Data dataUser;

    private boolean mShouldMakePurchase = false;
    private boolean mPurchased = false;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    // TODO: Rename and change types of parameters
    AddGroupViewModel addGroupViewModel;
    CreateGroupFragmentBinding binding;
    List<ContactDao> duplicatList = new ArrayList<>();
    List<ContactDao> contactList;
    GroupAdapter groupAdapter;

    private static CreateGroupFragment instance = null;

    // TODO: Rename and change types and number of parameters
    public static CreateGroupFragment getInstance() {
        if (instance == null) {
            instance = new CreateGroupFragment();
        }
        return instance;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater, R.layout.create_group_fragment, null, false);
        View view = binding.getRoot();
        initView();

        if (savedInstanceState != null) {
            if (savedInstanceState.containsKey(KEY_NONCE)) {
                mNonce = savedInstanceState.getParcelable(KEY_NONCE);
            }
        }
        return view;
    }

    private void initView() {

        //set toolbar appearance

        setActionBar();

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());
        binding.contactRv.setLayoutManager(layoutManager);

        DividerItemDecoration mDividerItemDecoration = new DividerItemDecoration(
                binding.contactRv.getContext(),
                DividerItemDecoration.VERTICAL
        );
        binding.contactRv.addItemDecoration(mDividerItemDecoration);
        addGroupViewModel = new AddGroupViewModel(CreateGroupFragment.this, binding.mSwipeRefreshLayout);
        binding.mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Refresh items
                addGroupViewModel.init();
            }
        });

        binding.newGroup.setOnClickListener(this);
        getDataFromPref();
    }

    private void setActionBar() {
        ((MainActivity) getActivity()).showActionBarTitleBgColor(true, R.string.create_group, R.color.actionBarColor);

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                getActivity().getSupportFragmentManager().popBackStack();
                break;
        }
        return true;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_search, menu);

        final MenuItem myActionMenuItem = menu.findItem(R.id.action_search);
        final SearchView searchView = (SearchView) myActionMenuItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // Toast like print
                Log.d("searchResult", query);
                //UserFeedback.show( "SearchOnQueryTextSubmit: " + query);
                if (!searchView.isIconified()) {
                    searchView.setIconified(true);
                }
                myActionMenuItem.collapseActionView();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                // UserFeedback.show( "SearchOnQueryTextChanged: " + s);
                if (s != null && contactList != null&& contactList.size()>0) {
                    if (duplicatList.size() == 0) {
                        duplicatList.addAll(contactList);

                    }
                    contactList.clear();
                    for (ContactDao contactDao : duplicatList) {
                        if (contactDao.getName().toLowerCase().startsWith(s.toString().toLowerCase()) || contactDao.getPhone().startsWith(s.toString())) {
                            contactList.add(contactDao);
                        }
                    }
                    groupAdapter.notifyDataSetChanged();
                } else {
                    contactList.addAll(duplicatList);
                    duplicatList.clear();
                    groupAdapter.notifyDataSetChanged();
                }
                Log.d("searchResult", s);
                return false;
            }
        });
        super.onCreateOptionsMenu(menu, inflater);
    }

    public void getDataFromPref() {
        contactList = PreferanceUtils.getContactListFromPreferance(getActivity()).getContactList();
        if (contactList != null) {
            if (contactList.size() > 0) {

                groupAdapter = new GroupAdapter(getActivity(), contactList);
                binding.contactRv.setAdapter(groupAdapter);
            } else {
                addGroupViewModel.init();
            }
        } else {
            addGroupViewModel.init();
        }
    }


    public void setDataList(List<ContactDao> contactList) {
        this.contactList = contactList;
        if (groupAdapter == null) {
            groupAdapter = new GroupAdapter(getActivity(), contactList);
            binding.contactRv.setAdapter(groupAdapter);
        } else {
            groupAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.newGroup:
                groupName = binding.groupnameET.getText().toString();
                selectedMember = new ArrayList<>();
                dataUser = PreferanceUtils.getLoginDetail(getActivity()).getData();
                for (ContactDao contactDao : contactList) {
                    if (contactDao.isSelected()) {
                        GroupItemDao groupItemDao = new GroupItemDao();
                        groupItemDao.setId(contactDao.getId());
                        groupItemDao.setName(contactDao.getName());
                        selectedMember.add(groupItemDao);
                    }
                }
                GroupItemDao groupItemDao = new GroupItemDao();
                groupItemDao.setId(dataUser.getId());
                groupItemDao.setName(dataUser.getName());
                selectedMember.add(groupItemDao);
                if (groupName.isEmpty())
                    binding.groupnameET.setError("Enter Group Name");
                else if (selectedMember.size() == 0)
                    Utills.showSnackToast("Atleast select one member", getActivity());
                else {
                    //launchDropIn();
                    amount = 2 * (selectedMember.size() - 1) + "";
                    launchDropIn(amount);
                    /*CreateGroupDao createGroupDao = new CreateGroupDao();
                    createGroupDao.setParticipant(selectedMember);
                    createGroupDao.setGroupName(groupName);
                    createGroupDao.setInvoice_number("hdhasghsgjdgj");
                    createGroupDao.setRency_code("USD");
                    createGroupDao.setAmount("50");
                    createGroupDao.setCreate_time("23/04/2000 5:30");
                    createGroupDao.setType("android");
                    addGroupViewModel.createGroup(data.getId(), createGroupDao);*/
                }

        }

    }


    @Override
    public void onResume() {
        super.onResume();

        if (mPurchased) {
            mPurchased = false;

            try {
                if (ClientToken.fromString(mAuthorization) instanceof com.braintreepayments.api.models.ClientToken) {
                    DropInResult.fetchDropInResult(getActivity(), mAuthorization, this);
                } else {
                    //mAddPaymentMethodButton.setVisibility(VISIBLE);
                }
            } catch (InvalidArgumentException e) {
                //mAddPaymentMethodButton.setVisibility(VISIBLE);
            }
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mNonce != null) {
            outState.putParcelable(KEY_NONCE, mNonce);
        }
    }


    public void launchDropIn(String amount) {
        DropInRequest dropInRequest = new DropInRequest()
                .clientToken(mAuthorization)
                .amount(amount)
                .requestThreeDSecureVerification(Settings.isThreeDSecureEnabled(getActivity()))
                .collectDeviceData(Settings.shouldCollectDeviceData(getActivity()))
                .googlePaymentRequest(getGooglePaymentRequest(amount))
                .maskCardNumber(true)
                .maskSecurityCode(true)
                .androidPayCart(getAndroidPayCart(amount))
                .androidPayShippingAddressRequired(Settings.isAndroidPayShippingAddressRequired(getActivity()))
                .androidPayPhoneNumberRequired(Settings.isAndroidPayPhoneNumberRequired(getActivity()))
                .androidPayAllowedCountriesForShipping(Settings.getAndroidPayAllowedCountriesForShipping(getActivity()));

        if (Settings.isPayPalAddressScopeRequested(getActivity())) {
            dropInRequest.paypalAdditionalScopes(Collections.singletonList(PayPal.SCOPE_ADDRESS));
        }

        startActivityForResult(dropInRequest.getIntent(getActivity()), DROP_IN_REQUEST);
    }

    public void purchase(View v) {
        if (mPaymentMethodType == PaymentMethodType.ANDROID_PAY && mNonce == null) {
            ArrayList<CountrySpecification> countries = new ArrayList<>();
            for (String countryCode : Settings.getAndroidPayAllowedCountriesForShipping(getActivity())) {
                countries.add(new CountrySpecification(countryCode));
            }

            mShouldMakePurchase = true;

            AndroidPay.requestAndroidPay(mBraintreeFragment, getAndroidPayCart(amount),
                    Settings.isAndroidPayShippingAddressRequired(getActivity()),
                    Settings.isAndroidPayPhoneNumberRequired(getActivity()), countries);
        } else {
            Intent intent = new Intent(getActivity(), CreateTransactionActivity.class)
                    .putExtra(CreateTransactionActivity.EXTRA_PAYMENT_METHOD_NONCE, mNonce);
            startActivity(intent);

            mPurchased = true;
        }
    }

    @Override
    public void onResult(DropInResult result) {
        if (result.getPaymentMethodType() == null) {

        } else {


            mPaymentMethodType = result.getPaymentMethodType();

            if (result.getPaymentMethodNonce() != null) {
                displayResult(result.getPaymentMethodNonce(), result.getDeviceData());
            } else if (result.getPaymentMethodType() == PaymentMethodType.ANDROID_PAY) {
                //mPaymentMethodTitle.setText(PaymentMethodType.ANDROID_PAY.getLocalizedName());
                //mPaymentMethodDescription.setText("");
                //mPaymentMethod.setVisibility(VISIBLE);
            }

            //mPurchaseButton.setEnabled(true);
        }
    }

    @Override
    public void onPaymentMethodNonceCreated(PaymentMethodNonce paymentMethodNonce) {
        super.onPaymentMethodNonceCreated(paymentMethodNonce);

        displayResult(paymentMethodNonce, null);
        safelyCloseLoadingView();

        if (mShouldMakePurchase) {
            purchase(null);
        }
    }

    @Override
    public void onCancel(int requestCode) {
        super.onCancel(requestCode);

        safelyCloseLoadingView();

        mShouldMakePurchase = false;
    }

    @Override
    public void onError(Exception error) {
        super.onError(error);

        safelyCloseLoadingView();

        mShouldMakePurchase = false;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        safelyCloseLoadingView();

        if (resultCode == Activity.RESULT_OK) {
            DropInResult result = data.getParcelableExtra(DropInResult.EXTRA_DROP_IN_RESULT);
            displayResult(result.getPaymentMethodNonce(), result.getDeviceData());
            trnId = result.getPaymentMethodNonce().getNonce();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm");
            String currentDateandTime = simpleDateFormat.format(new Date());
            CreateGroupDao createGroupDao = new CreateGroupDao();
            createGroupDao.setParticipant(selectedMember);
            createGroupDao.setGroupName(groupName);
            createGroupDao.setInvoice_number(trnId);
            createGroupDao.setRency_code("USD");
            createGroupDao.setAmount(amount);
            createGroupDao.setCreate_time(currentDateandTime);
            createGroupDao.setType("android");
            addGroupViewModel.createGroup(dataUser.getId(), createGroupDao);
            //mPurchaseButton.setEnabled(true);
        } else if (resultCode != Activity.RESULT_CANCELED) {
            safelyCloseLoadingView();
            showDialog(((Exception) data.getSerializableExtra(DropInActivity.EXTRA_ERROR))
                    .getMessage());
        }
    }

    @Override
    protected void reset() {
        //mPurchaseButton.setEnabled(false);
        //mAddPaymentMethodButton.setVisibility(GONE);
    }

    @Override
    protected void onAuthorizationFetched() {
        try {
            mBraintreeFragment = BraintreeFragment.newInstance(getActivity(), mAuthorization);

            if (ClientToken.fromString(mAuthorization) instanceof ClientToken) {
                DropInResult.fetchDropInResult(getActivity(), mAuthorization, this);
            } else {
                //mAddPaymentMethodButton.setVisibility(VISIBLE);
            }
        } catch (InvalidArgumentException e) {
            showDialog(e.getMessage());
        }
    }

    private void displayResult(PaymentMethodNonce paymentMethodNonce, String deviceData) {
        mNonce = paymentMethodNonce;
        mPaymentMethodType = PaymentMethodType.forType(mNonce);

        /*mPaymentMethodIcon.setImageResource(PaymentMethodType.forType(mNonce).getDrawable());
        mPaymentMethodTitle.setText(paymentMethodNonce.getTypeLabel());
        mPaymentMethodDescription.setText(paymentMethodNonce.getDescription());
        mPaymentMethod.setVisibility(VISIBLE);

        mNonceString.setText(getString(R.string.nonce) + ": " + mNonce.getNonce());
        mNonceString.setVisibility(VISIBLE);
*/
        String details = "";
        if (mNonce instanceof CardNonce) {
            CardNonce cardNonce = (CardNonce) mNonce;

            details = "Card Last Two: " + cardNonce.getLastTwo() + "\n";
            details += "3DS isLiabilityShifted: " + cardNonce.getThreeDSecureInfo().isLiabilityShifted() + "\n";
            details += "3DS isLiabilityShiftPossible: " + cardNonce.getThreeDSecureInfo().isLiabilityShiftPossible();
        } else if (mNonce instanceof PayPalAccountNonce) {
            PayPalAccountNonce paypalAccountNonce = (PayPalAccountNonce) mNonce;

            details = "First name: " + paypalAccountNonce.getFirstName() + "\n";
            details += "Last name: " + paypalAccountNonce.getLastName() + "\n";
            details += "Email: " + paypalAccountNonce.getEmail() + "\n";
            details += "Phone: " + paypalAccountNonce.getPhone() + "\n";
            details += "Payer id: " + paypalAccountNonce.getPayerId() + "\n";
            details += "Client metadata id: " + paypalAccountNonce.getClientMetadataId() + "\n";
            details += "Billing address: " + formatAddress(paypalAccountNonce.getBillingAddress()) + "\n";
            details += "Shipping address: " + formatAddress(paypalAccountNonce.getShippingAddress());

        } else if (mNonce instanceof AndroidPayCardNonce) {
            AndroidPayCardNonce androidPayCardNonce = (AndroidPayCardNonce) mNonce;

            details = "Underlying Card Last Two: " + androidPayCardNonce.getLastTwo() + "\n";
            details += "Email: " + androidPayCardNonce.getEmail() + "\n";
            details += "Billing address: " + formatAddress(androidPayCardNonce.getBillingAddress()) + "\n";
            details += "Shipping address: " + formatAddress(androidPayCardNonce.getShippingAddress());
        } else if (mNonce instanceof VenmoAccountNonce) {
            VenmoAccountNonce venmoAccountNonce = (VenmoAccountNonce) mNonce;

            details = "Username: " + venmoAccountNonce.getUsername();
        } else if (mNonce instanceof GooglePaymentCardNonce) {
            GooglePaymentCardNonce googlePaymentCardNonce = (GooglePaymentCardNonce) mNonce;

            details = "Underlying Card Last Two: " + googlePaymentCardNonce.getLastTwo() + "\n";
            details += "Email: " + googlePaymentCardNonce.getEmail() + "\n";
            details += "Billing address: " + formatAddress(googlePaymentCardNonce.getBillingAddress()) + "\n";
            details += "Shipping address: " + formatAddress(googlePaymentCardNonce.getShippingAddress());
        }


        /*mNonceDetails.setText(details);
        mNonceDetails.setVisibility(VISIBLE);

        mDeviceData.setText("Device Data: " + deviceData);
        mDeviceData.setVisibility(VISIBLE);

        mAddPaymentMethodButton.setVisibility(GONE);
        mPurchaseButton.setEnabled(true);*/
    }

    private String formatAddress(PostalAddress address) {
        return address.getRecipientName() + " " + address.getStreetAddress() + " " +
                address.getExtendedAddress() + " " + address.getLocality() + " " + address.getRegion() +
                " " + address.getPostalCode() + " " + address.getCountryCodeAlpha2();
    }

    private String formatAddress(UserAddress address) {
        if (address == null) {
            return "null";
        }
        return address.getName() + " " + address.getAddress1() + " " + address.getAddress2() + " " +
                address.getAddress3() + " " + address.getAddress4() + " " + address.getAddress5() + " " +
                address.getLocality() + " " + address.getAdministrativeArea() + " " + address.getPostalCode() + " " +
                address.getSortingCode() + " " + address.getCountryCode();
    }

    private GooglePaymentRequest getGooglePaymentRequest(String amount) {
        return new GooglePaymentRequest()
                .transactionInfo(TransactionInfo.newBuilder()
                        .setTotalPrice(amount)
                        .setCurrencyCode("USD")
                        .setTotalPriceStatus(WalletConstants.TOTAL_PRICE_STATUS_FINAL)
                        .build())
                .emailRequired(true);
    }

    private Cart getAndroidPayCart(String amount) {
        return Cart.newBuilder()
                .setCurrencyCode(Settings.getAndroidPayCurrency(getActivity()))
                .setTotalPrice(amount)
                .addLineItem(LineItem.newBuilder()
                        .setCurrencyCode("USD")
                        .setDescription("Description")
                        .setQuantity("1")
                        .setUnitPrice(amount)
                        .setTotalPrice(amount)
                        .build())
                .build();
    }

    private void safelyCloseLoadingView() {
        if (mLoading != null && mLoading.isShowing()) {
            mLoading.dismiss();
        }
    }
}